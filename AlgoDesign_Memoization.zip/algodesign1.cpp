#include "bits/stdc++.h"
using namespace std;

bool howSum(int target, vector<int> &numbers, int i, vector<int> &res, unordered_map<int, bool> &memo) {
    // Memoization by checking whether already the target is stored or not. 
    // If already processed then return the memo value

    /*
    Time Complexity - O(target * n)
    Space Complexity - O(target)
    */
    if(memo.find(target) != memo.end())
        return memo[target];
    
    // Base Case
    if(i == numbers.size() || target == 0) {
        return target == 0;
    }

    // If the numbers[i] can be subtracted with target then pick the element and stay in the same index
    if(target - numbers[i] >= 0) {
        res.push_back(numbers[i]);

        // If a combination is already found then return true
        if(howSum(target - numbers[i], numbers, i, res, memo))

        // Store it in memo map
            return memo[target] = true;
        res.pop_back();
    }

    // Don't pick and move to the next element
    // Store it in memo map
    return memo[target] = howSum(target, numbers, i + 1, res, memo);
}

int main() {
    int testcase, n, target;

    cin >> testcase;

    for(int i = 0;i < testcase;i++) {
        cout << "Testcase " << i + 1 << ":" << endl;

        cin >> target >> n;
        vector<int> numbers(n);
        vector<int> res;
        unordered_map<int, bool> memo;

        cout << "Target = " << target << endl;
        
        // Get the input arrayB
        for(int j = 0;j < n;j++) {
            cin >> numbers[j];
        }


        
        // Call the howSum() function and if it is true then combination exists
        if(howSum(target, numbers, 0, res, memo)) {
            cout << "Combination that adds up to target " << target << " is:\n"; 
            for(auto num : res) {
                cout << num << " ";
            }
        }
        else {
            cout << "No valid Combination exists for target " << target;
        }
        cout << endl;
        cout << "--------------------------------------------" << endl;
    }  
    return 0;
}
